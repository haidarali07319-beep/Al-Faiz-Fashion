package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.repository.ShopRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class ShopRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private lateinit var repository: ShopRepository

    @Before
    override fun setUpFirebase() {
        super.setUpFirebase()
        repository = ShopRepository(firestore)
    }

    @Test
    fun testProductLifecycle_authenticatedUser() = runBlocking {
        val uid = signInTestUser("merchant_alice@example.com")

        // Add Product
        repository.addProduct(uid, "Designer Sherwani", 4500.0, 12, "Men")

        val products = repository.observeProducts(uid).first()
        assertTrue("Products list should not be empty", products.isNotEmpty())
        val product = products.first()
        assertEquals("Designer Sherwani", product.name)
        assertEquals(4500.0, product.price, 0.01)
        assertEquals(12, product.stock)

        // Update Product
        repository.updateProduct(uid, product.copy(price = 4200.0, stock = 10))
        val updatedProducts = repository.observeProducts(uid).first()
        val updated = updatedProducts.first { it.id == product.id }
        assertEquals(4200.0, updated.price, 0.01)
        assertEquals(10, updated.stock)

        // Delete Product
        repository.deleteProduct(uid, product.id)
        val afterDelete = repository.observeProducts(uid).first()
        assertTrue("Product should be deleted", afterDelete.none { it.id == product.id })
    }

    @Test
    fun testCustomerAndPaymentLifecycle_authenticatedUser() = runBlocking {
        val uid = signInTestUser("merchant_khata@example.com")

        // Add Customer
        repository.addCustomer(uid, "Ahmed Khan", "9876543210", 3000.0, "Near Clock Tower")
        val customers = repository.observeCustomers(uid).first()
        assertTrue(customers.isNotEmpty())
        val customer = customers.first()
        assertEquals("Ahmed Khan", customer.name)
        assertEquals(3000.0, customer.balance, 0.01)

        // Record Payment (reduces balance)
        repository.recordPayment(uid, customer.id, customer.name, 1000.0, customer.balance, "Partial cash payment")

        val updatedCustomers = repository.observeCustomers(uid).first()
        val afterPayment = updatedCustomers.first { it.id == customer.id }
        assertEquals(2000.0, afterPayment.balance, 0.01)

        val payments = repository.observePayments(uid).first()
        assertTrue(payments.isNotEmpty())
        val payment = payments.first()
        assertEquals(customer.id, payment.customerId)
        assertEquals(1000.0, payment.amount, 0.01)
    }

    @Test
    fun testOptionalNullFieldsUpdate_succeeds() = runBlocking {
        val uid = signInTestUser("merchant_optional@example.com")

        // Add product without category
        repository.addProduct(uid, "Plain Kurta", 999.0, 5, null)
        val product = repository.observeProducts(uid).first().first { it.name == "Plain Kurta" }
        repository.updateProduct(uid, product.copy(price = 1099.0, category = null))
        val updatedProduct = repository.observeProducts(uid).first().first { it.id == product.id }
        assertEquals(1099.0, updatedProduct.price, 0.01)

        // Add customer without address
        repository.addCustomer(uid, "Zaid", "", 500.0, null)
        val customer = repository.observeCustomers(uid).first().first { it.name == "Zaid" }
        repository.updateCustomer(uid, customer.copy(balance = 750.0, address = null))
        val updatedCustomer = repository.observeCustomers(uid).first().first { it.id == customer.id }
        assertEquals(750.0, updatedCustomer.balance, 0.01)
    }

    @Test
    fun testCrossUserIsolation_bobCannotAccessAliceData() = runBlocking {
        val aliceUid = signInTestUser("alice_secret@example.com")
        repository.addProduct(aliceUid, "Silk Saree", 8000.0, 3)

        // Sign in as Bob
        val bobUid = signInTestUser("bob_intruder@example.com")
        try {
            repository.observeProducts(aliceUid).first()
            fail("Bob should not be able to read Alice's products")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Should throw FirebaseFirestoreException", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }
    }
}
