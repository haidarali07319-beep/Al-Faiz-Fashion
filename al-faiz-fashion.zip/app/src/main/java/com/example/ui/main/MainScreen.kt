package com.example.ui.main

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.auth.signOutUser
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.khata.KhataScreen
import com.example.ui.payments.PaymentsScreen
import com.example.ui.products.ProductsScreen
import com.example.ui.theme.DeepPurpleDark
import com.example.ui.theme.DeepPurplePrimary
import com.example.ui.theme.FashionGold
import com.example.ui.viewmodel.ShopViewModel
import kotlinx.coroutines.flow.collectLatest

enum class MainTab(val titleRes: Int) {
    HOME(R.string.nav_dashboard),
    PRODUCTS(R.string.nav_products),
    KHATA(R.string.nav_khata),
    PAYMENTS(R.string.nav_payments)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: ShopViewModel,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }

    var currentTab by rememberSaveable { mutableIntStateOf(MainTab.HOME.ordinal) }
    var showLogoutConfirm by remember { mutableStateOf(false) }

    // Quick action flags triggered from Dashboard
    var triggerAddProduct by remember { mutableStateOf(false) }
    var triggerAddCustomer by remember { mutableStateOf(false) }

    // Collect user notifications / snackbars
    LaunchedEffect(viewModel) {
        viewModel.userMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Back handling: If on secondary tab, return to Home
    BackHandler(enabled = currentTab != MainTab.HOME.ordinal) {
        currentTab = MainTab.HOME.ordinal
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Default.Store,
                            contentDescription = "Shop icon",
                            tint = FashionGold,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showLogoutConfirm = true },
                        modifier = Modifier.testTag("logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = stringResource(R.string.logout),
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = DeepPurplePrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                // Tab 0: Home / Dashboard
                NavigationBarItem(
                    selected = currentTab == MainTab.HOME.ordinal,
                    onClick = { currentTab = MainTab.HOME.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.HOME.ordinal) Icons.Filled.Dashboard else Icons.Outlined.Dashboard,
                            contentDescription = stringResource(R.string.nav_dashboard)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_dashboard)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepPurpleDark,
                        indicatorColor = FashionGold.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_home_tab")
                )

                // Tab 1: Products
                NavigationBarItem(
                    selected = currentTab == MainTab.PRODUCTS.ordinal,
                    onClick = { currentTab = MainTab.PRODUCTS.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.PRODUCTS.ordinal) Icons.Filled.Checkroom else Icons.Outlined.Checkroom,
                            contentDescription = stringResource(R.string.nav_products)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_products)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepPurpleDark,
                        indicatorColor = FashionGold.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_products_tab")
                )

                // Tab 2: Khata
                NavigationBarItem(
                    selected = currentTab == MainTab.KHATA.ordinal,
                    onClick = { currentTab = MainTab.KHATA.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.KHATA.ordinal) Icons.Filled.People else Icons.Outlined.People,
                            contentDescription = stringResource(R.string.nav_khata)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_khata)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepPurpleDark,
                        indicatorColor = FashionGold.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_khata_tab")
                )

                // Tab 3: Payments
                NavigationBarItem(
                    selected = currentTab == MainTab.PAYMENTS.ordinal,
                    onClick = { currentTab = MainTab.PAYMENTS.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.PAYMENTS.ordinal) Icons.AutoMirrored.Filled.ReceiptLong else Icons.AutoMirrored.Outlined.ReceiptLong,
                            contentDescription = stringResource(R.string.nav_payments)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_payments)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepPurpleDark,
                        indicatorColor = FashionGold.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_payments_tab")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MainTab.HOME.ordinal -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToProducts = { currentTab = MainTab.PRODUCTS.ordinal },
                    onNavigateToKhata = { currentTab = MainTab.KHATA.ordinal },
                    onOpenAddProductDialog = {
                        triggerAddProduct = true
                        currentTab = MainTab.PRODUCTS.ordinal
                    },
                    onOpenAddCustomerDialog = {
                        triggerAddCustomer = true
                        currentTab = MainTab.KHATA.ordinal
                    }
                )
                MainTab.PRODUCTS.ordinal -> ProductsScreen(
                    viewModel = viewModel,
                    showAddDialogInitially = triggerAddProduct,
                    onAddDialogClosed = { triggerAddProduct = false }
                )
                MainTab.KHATA.ordinal -> KhataScreen(
                    viewModel = viewModel,
                    showAddDialogInitially = triggerAddCustomer,
                    onAddDialogClosed = { triggerAddCustomer = false }
                )
                MainTab.PAYMENTS.ordinal -> PaymentsScreen(
                    viewModel = viewModel
                )
            }
        }
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text(stringResource(R.string.logout)) },
            text = { Text("Are you sure you want to sign out of Al-Faiz Fashion?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutConfirm = false
                        signOutUser(credentialManager, scope, onSignOut)
                    }
                ) {
                    Text("Sign Out", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}
