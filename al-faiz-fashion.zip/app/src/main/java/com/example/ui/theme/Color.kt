package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Deep Purple shades
val DeepPurplePrimary = Color(0xFF673AB7)
val DeepPurpleDark = Color(0xFF3B1E54)
val DeepPurpleLight = Color(0xFFD0BCFF)
val DeepPurpleContainer = Color(0xFFEDE7F6)
val OnDeepPurpleContainer = Color(0xFF260E43)

// Secondary & Accent Gold
val FashionGold = Color(0xFFD4AF37)
val FashionGoldLight = Color(0xFFFFE082)
val GoldContainer = Color(0xFFFFF8E1)

// Neutral surfaces
val SurfaceLight = Color(0xFFFAF7FC)
val SurfaceVariantLight = Color(0xFFF3EDF7)
val SurfaceDark = Color(0xFF16121C)
val SurfaceVariantDark = Color(0xFF272130)

// Semantic status colors
val PositiveGreen = Color(0xFF2E7D32)
val DueAmber = Color(0xFFD84315)
val AlertRed = Color(0xFFC62828)
