package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DeepPurpleLight,
    onPrimary = DeepPurpleDark,
    primaryContainer = DeepPurpleDark,
    onPrimaryContainer = DeepPurpleLight,
    secondary = FashionGoldLight,
    onSecondary = Color(0xFF3F2E00),
    secondaryContainer = Color(0xFF5B4300),
    onSecondaryContainer = FashionGoldLight,
    background = SurfaceDark,
    onBackground = Color(0xFFE6E1E9),
    surface = SurfaceDark,
    onSurface = Color(0xFFE6E1E9),
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = Color(0xFFCAC4D0)
)

private val LightColorScheme = lightColorScheme(
    primary = DeepPurplePrimary,
    onPrimary = Color.White,
    primaryContainer = DeepPurpleContainer,
    onPrimaryContainer = OnDeepPurpleContainer,
    secondary = FashionGold,
    onSecondary = Color.Black,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = Color(0xFF4C3B00),
    background = SurfaceLight,
    onBackground = Color(0xFF1D1B20),
    surface = SurfaceLight,
    onSurface = Color(0xFF1D1B20),
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = Color(0xFF49454F)
)

@Composable
fun AlFaizFashionTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded purple/gold theme consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
