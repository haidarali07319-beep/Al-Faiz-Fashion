const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

const PROJECT_ID = "demo-no-project";
const DATABASE_ID = "ai-studio-android-alfaizfa-f36ef48b-f873-43cf-9f14-addaad041f75";

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync("firestore.rules", "utf8"),
      host: "127.0.0.1",
      port: 8085
    }
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write products", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore(DATABASE_ID);
  const productRef = unauthedDb.doc("users/user123/products/prod1");

  await assertFails(productRef.get());
  await assertFails(productRef.set({
    name: "Embroidered Kurta",
    price: 1499.0,
    stock: 10,
    createdAt: new Date()
  }));
});

test("Authenticated user can manage their own products", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore(DATABASE_ID);
  const productRef = aliceDb.doc("users/alice/products/prod1");

  // Create
  await assertSucceeds(productRef.set({
    name: "Embroidered Kurta",
    price: 1499.0,
    stock: 10,
    createdAt: new Date()
  }));

  // Read
  await assertSucceeds(productRef.get());

  // Update
  await assertSucceeds(productRef.update({
    price: 1399.0,
    stock: 8,
    updatedAt: new Date()
  }));

  // Delete
  await assertSucceeds(productRef.delete());
});

test("User cannot access another user's products", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext("bob").firestore(DATABASE_ID);

  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore(DATABASE_ID).doc("users/alice/products/prod1").set({
      name: "Designer Saree",
      price: 4999.0,
      stock: 5,
      createdAt: new Date()
    });
  });

  await assertFails(bobDb.doc("users/alice/products/prod1").get());
  await assertFails(bobDb.collection("users/alice/products").get());
  await assertFails(bobDb.doc("users/alice/products/prod1").update({ price: 3000 }));
  await assertFails(bobDb.doc("users/alice/products/prod1").delete());
});

test("Product validation rejects negative price or stock or invalid fields", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore(DATABASE_ID);
  const productRef = aliceDb.doc("users/alice/products/prod2");

  // Negative price fails
  await assertFails(productRef.set({
    name: "Cotton Shirt",
    price: -100,
    stock: 5,
    createdAt: new Date()
  }));

  // Negative stock fails
  await assertFails(productRef.set({
    name: "Cotton Shirt",
    price: 500,
    stock: -1,
    createdAt: new Date()
  }));

  // Extra unauthorized ghost key fails
  await assertFails(productRef.set({
    name: "Cotton Shirt",
    price: 500,
    stock: 5,
    createdAt: new Date(),
    ghostKey: "illegal"
  }));
});

test("Customer Khata management: create, read, update, payment logging", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore(DATABASE_ID);
  const customerRef = aliceDb.doc("users/alice/customers/cust1");

  // Create customer with due balance
  await assertSucceeds(customerRef.set({
    name: "Mohammad Ali",
    phone: "9876543210",
    balance: 2500.0,
    createdAt: new Date()
  }));

  // Read customer
  await assertSucceeds(customerRef.get());

  // Update customer balance (e.g., after partial payment)
  await assertSucceeds(customerRef.update({
    balance: 1500.0,
    updatedAt: new Date()
  }));

  // Create payment log entry
  const paymentRef = aliceDb.doc("users/alice/payments/pay1");
  await assertSucceeds(paymentRef.set({
    customerId: "cust1",
    customerName: "Mohammad Ali",
    amount: 1000.0,
    note: "Cash payment",
    createdAt: new Date()
  }));

  // Payment is immutable: updates and deletes are rejected
  await assertFails(paymentRef.update({ amount: 500.0 }));
  await assertFails(paymentRef.delete());
});
