package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Customer
import com.example.data.model.Payment
import com.example.data.model.Product
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ShopRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    // --- Products ---

    fun observeProducts(userId: String): Flow<List<Product>> {
        val path = "users/$userId/products"
        return db.collection("users").document(userId).collection("products")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Product::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
    }

    suspend fun addProduct(userId: String, name: String, price: Double, stock: Int, category: String? = null) {
        val docRef = db.collection("users").document(userId).collection("products").document()
        val payload = mutableMapOf<String, Any>(
            "name" to name.trim(),
            "price" to price,
            "stock" to stock,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!category.isNullOrBlank()) {
            payload["category"] = category.trim()
        }
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateProduct(userId: String, product: Product) {
        require(product.id.isNotBlank()) { "Product ID must not be blank" }
        val docRef = db.collection("users").document(userId).collection("products").document(product.id)
        val updates = mutableMapOf<String, Any>(
            "name" to product.name.trim(),
            "price" to product.price,
            "stock" to product.stock,
            "updatedAt" to FieldValue.serverTimestamp(),
            "category" to (product.category?.takeIf { it.isNotBlank() }?.trim() ?: FieldValue.delete())
        )
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteProduct(userId: String, productId: String) {
        require(productId.isNotBlank()) { "Product ID must not be blank" }
        val docRef = db.collection("users").document(userId).collection("products").document(productId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- Customers (Khata) ---

    fun observeCustomers(userId: String): Flow<List<Customer>> {
        return db.collection("users").document(userId).collection("customers")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Customer::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
    }

    suspend fun addCustomer(userId: String, name: String, phone: String, balance: Double, address: String? = null) {
        val docRef = db.collection("users").document(userId).collection("customers").document()
        val payload = mutableMapOf<String, Any>(
            "name" to name.trim(),
            "phone" to phone.trim(),
            "balance" to balance,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!address.isNullOrBlank()) {
            payload["address"] = address.trim()
        }
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateCustomer(userId: String, customer: Customer) {
        require(customer.id.isNotBlank()) { "Customer ID must not be blank" }
        val docRef = db.collection("users").document(userId).collection("customers").document(customer.id)
        val updates = mutableMapOf<String, Any>(
            "name" to customer.name.trim(),
            "phone" to customer.phone.trim(),
            "balance" to customer.balance,
            "updatedAt" to FieldValue.serverTimestamp(),
            "address" to (customer.address?.takeIf { it.isNotBlank() }?.trim() ?: FieldValue.delete())
        )
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteCustomer(userId: String, customerId: String) {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val docRef = db.collection("users").document(userId).collection("customers").document(customerId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun recordPayment(
        userId: String,
        customerId: String,
        customerName: String,
        paidAmount: Double,
        currentBalance: Double,
        note: String? = null
    ) {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        require(paidAmount > 0) { "Paid amount must be greater than zero" }

        val customerRef = db.collection("users").document(userId).collection("customers").document(customerId)
        val paymentRef = db.collection("users").document(userId).collection("payments").document()

        val newBalance = (currentBalance - paidAmount).coerceAtLeast(0.0)
        val paymentPayload = mutableMapOf<String, Any>(
            "customerId" to customerId,
            "customerName" to customerName,
            "amount" to paidAmount,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!note.isNullOrBlank()) {
            paymentPayload["note"] = note.trim()
        }

        try {
            val batch = db.batch()
            batch.update(customerRef, mapOf(
                "balance" to newBalance,
                "updatedAt" to FieldValue.serverTimestamp()
            ))
            batch.set(paymentRef, paymentPayload)
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$userId/payments")
            throw e
        }
    }

    // --- Payments ---

    fun observePayments(userId: String): Flow<List<Payment>> {
        return db.collection("users").document(userId).collection("payments")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Payment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
    }
}
