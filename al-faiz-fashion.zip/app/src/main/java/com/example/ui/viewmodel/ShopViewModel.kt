package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.Payment
import com.example.data.model.Product
import com.example.data.repository.ShopRepository
import com.example.ui.common.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardStats(
    val totalCustomerDue: Double = 0.0,
    val totalProducts: Int = 0,
    val totalStockUnits: Int = 0,
    val lowStockCount: Int = 0
)

class ShopViewModel(
    private val repository: ShopRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    // --- Search & Filters ---
    private val _productSearchQuery = MutableStateFlow("")
    val productSearchQuery: StateFlow<String> = _productSearchQuery.asStateFlow()

    private val _customerSearchQuery = MutableStateFlow("")
    val customerSearchQuery: StateFlow<String> = _customerSearchQuery.asStateFlow()

    fun setProductSearch(query: String) {
        _productSearchQuery.value = query
    }

    fun setCustomerSearch(query: String) {
        _customerSearchQuery.value = query
    }

    // --- Realtime Streams with Two-tier Error Handling ---

    val rawProducts: StateFlow<UiState<List<Product>>> = repository.observeProducts(currentUserId)
        .map<List<Product>, UiState<List<Product>>> { UiState.Success(it) }
        .catch { error ->
            val rootError = error.unwrapFirestoreException() ?: error
            Log.w(TAG, "Error observing products: ${rootError.message}", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load products"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val products: StateFlow<UiState<List<Product>>> = combine(rawProducts, _productSearchQuery) { state, query ->
        when (state) {
            is UiState.Success -> {
                val filtered = if (query.isBlank()) {
                    state.data
                } else {
                    state.data.filter {
                        it.name.contains(query, ignoreCase = true) ||
                                (it.category?.contains(query, ignoreCase = true) == true)
                    }
                }
                UiState.Success(filtered)
            }
            is UiState.Error -> state
            UiState.Loading -> UiState.Loading
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading
    )

    val rawCustomers: StateFlow<UiState<List<Customer>>> = repository.observeCustomers(currentUserId)
        .map<List<Customer>, UiState<List<Customer>>> { UiState.Success(it) }
        .catch { error ->
            val rootError = error.unwrapFirestoreException() ?: error
            Log.w(TAG, "Error observing customers: ${rootError.message}", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load customers"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val customers: StateFlow<UiState<List<Customer>>> = combine(rawCustomers, _customerSearchQuery) { state, query ->
        when (state) {
            is UiState.Success -> {
                val filtered = if (query.isBlank()) {
                    state.data
                } else {
                    state.data.filter {
                        it.name.contains(query, ignoreCase = true) ||
                                it.phone.contains(query, ignoreCase = true)
                    }
                }
                UiState.Success(filtered)
            }
            is UiState.Error -> state
            UiState.Loading -> UiState.Loading
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading
    )

    val payments: StateFlow<UiState<List<Payment>>> = repository.observePayments(currentUserId)
        .map<List<Payment>, UiState<List<Payment>>> { UiState.Success(it) }
        .catch { error ->
            val rootError = error.unwrapFirestoreException() ?: error
            Log.w(TAG, "Error observing payments: ${rootError.message}", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load payments"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val stats: StateFlow<DashboardStats> = combine(rawProducts, rawCustomers) { productsState, customersState ->
        val prods = (productsState as? UiState.Success)?.data ?: emptyList()
        val custs = (customersState as? UiState.Success)?.data ?: emptyList()

        val totalDue = custs.sumOf { it.balance }
        val totalProducts = prods.size
        val totalStock = prods.sumOf { it.stock }
        val lowStock = prods.count { it.stock < 5 }

        DashboardStats(
            totalCustomerDue = totalDue,
            totalProducts = totalProducts,
            totalStockUnits = totalStock,
            lowStockCount = lowStock
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = DashboardStats()
    )

    // --- Action Methods ---

    fun addProduct(name: String, price: Double, stock: Int, category: String?, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.addProduct(currentUserId, name, price, stock, category)
                _userMessage.emit("Product \"$name\" added successfully")
                onComplete()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to add product", e)
                _userMessage.emit("Error adding product: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun updateProduct(product: Product, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.updateProduct(currentUserId, product)
                _userMessage.emit("Product updated")
                onComplete()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to update product", e)
                _userMessage.emit("Error updating product: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            try {
                repository.deleteProduct(currentUserId, productId)
                _userMessage.emit("Product removed")
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to delete product", e)
                _userMessage.emit("Error removing product: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun addCustomer(name: String, phone: String, initialBalance: Double, address: String?, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.addCustomer(currentUserId, name, phone, initialBalance, address)
                _userMessage.emit("Customer \"$name\" added to Khata")
                onComplete()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to add customer", e)
                _userMessage.emit("Error adding customer: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun updateCustomer(customer: Customer, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repository.updateCustomer(currentUserId, customer)
                _userMessage.emit("Customer details updated")
                onComplete()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to update customer", e)
                _userMessage.emit("Error updating customer: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun deleteCustomer(customerId: String) {
        viewModelScope.launch {
            try {
                repository.deleteCustomer(currentUserId, customerId)
                _userMessage.emit("Customer removed from Khata")
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to delete customer", e)
                _userMessage.emit("Error deleting customer: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun recordPayment(
        customerId: String,
        customerName: String,
        paidAmount: Double,
        currentBalance: Double,
        note: String?,
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                repository.recordPayment(currentUserId, customerId, customerName, paidAmount, currentBalance, note)
                _userMessage.emit("Payment of ₹$paidAmount recorded for $customerName")
                onComplete()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e(TAG, "Failed to record payment", e)
                _userMessage.emit("Error recording payment: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    private companion object {
        const val TAG = "ShopViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L

        fun Throwable.unwrapFirestoreException(): FirebaseFirestoreException? {
            var current: Throwable? = this
            while (current != null) {
                if (current is FirebaseFirestoreException) return current
                current = current.cause
            }
            return null
        }
    }
}
